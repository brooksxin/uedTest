define(['text!../tpl/test1.tpl'], function(tpl){
	return tpl;
})