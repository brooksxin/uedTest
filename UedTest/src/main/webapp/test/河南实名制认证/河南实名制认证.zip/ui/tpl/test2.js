define(['text!../tpl/test2.tpl'], function(tpl){
	return tpl;
})